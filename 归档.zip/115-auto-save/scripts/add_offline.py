#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
115网盘离线下载自动化脚本
使用Cookie方式调用115非官方API，将磁力链接/直链添加到离线下载任务

用法:
    python add_offline.py --cookie "UID=xxx; CID=xxx; SEID=xxx" --url "magnet:?xt=..."
    python add_offline.py --cookie-file ~/.115_cookie --url "magnet:?xt=..." --url "ed2k://..."
    python add_offline.py --cookie "..." --urls-file links.txt

环境变量（优先级低于命令行参数）:
    P115_COOKIE: 115网盘Cookie字符串
"""

import argparse
import json
import os
import sys
import time
import requests

# 目标目录CID（用户指定的115网盘目录）
DEFAULT_SAVE_CID = "591454992464977485"

# 115 API 端点
API_OFFLINE_SPACE = "https://115.com/?ct=offline&ac=space"
API_ADD_TASK_URL  = "https://115.com/web/lixian/?ct=lixian&ac=add_task_url"
API_ADD_TASK_URLS = "https://115.com/web/lixian/?ct=lixian&ac=add_task_urls"
API_TASK_LIST     = "https://115.com/web/lixian/?ct=lixian&ac=task_lists"

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Referer": "https://115.com/",
    "Origin":  "https://115.com",
}


def parse_cookie_string(cookie_str: str) -> dict:
    """将 'KEY=val; KEY2=val2' 格式的Cookie字符串解析为字典"""
    cookies = {}
    for part in cookie_str.split(";"):
        part = part.strip()
        if "=" in part:
            k, v = part.split("=", 1)
            cookies[k.strip()] = v.strip()
    return cookies


def get_sign_and_uid(session: requests.Session) -> tuple[str, str, str]:
    """
    从115 offline space接口获取 sign、uid、time
    这三个参数在每次提交离线任务时都需要携带
    """
    resp = session.get(API_OFFLINE_SPACE, headers=HEADERS, timeout=15)
    resp.raise_for_status()
    data = resp.json()

    if not data.get("state", False):
        error = data.get("error", "未知错误")
        raise RuntimeError(f"获取sign失败（可能Cookie已失效）: {error}")

    sign  = data["sign"]
    uid   = data["uid"]
    ts    = str(data["time"])
    return sign, uid, ts


def add_single_task(
    session: requests.Session,
    url: str,
    save_cid: str,
    sign: str,
    uid: str,
    ts: str,
) -> dict:
    """添加单个离线下载任务"""
    form = {
        "url":        url,
        "wp_path_id": save_cid,
        "uid":        uid,
        "sign":       sign,
        "time":       ts,
    }
    resp = session.post(API_ADD_TASK_URL, data=form, headers=HEADERS, timeout=20)
    resp.raise_for_status()
    return resp.json()


def add_multiple_tasks(
    session: requests.Session,
    urls: list[str],
    save_cid: str,
    sign: str,
    uid: str,
    ts: str,
) -> dict:
    """批量添加离线下载任务（最多15个）"""
    form = {
        "wp_path_id": save_cid,
        "uid":        uid,
        "sign":       sign,
        "time":       ts,
    }
    for i, url in enumerate(urls[:15]):
        form[f"url[{i}]"] = url

    resp = session.post(API_ADD_TASK_URLS, data=form, headers=HEADERS, timeout=20)
    resp.raise_for_status()
    return resp.json()


def add_offline_tasks(
    cookie_str: str,
    urls: list[str],
    save_cid: str = DEFAULT_SAVE_CID,
    verbose: bool = True,
) -> dict:
    """
    主入口：接受Cookie字符串和URL列表，提交离线任务

    返回:
        {
            "success": [{"url": ..., "name": ...}, ...],
            "failed":  [{"url": ..., "reason": ...}, ...],
            "save_dir": "https://115.com/?cid=...",
        }
    """
    if not urls:
        return {"success": [], "failed": [], "save_dir": f"https://115.com/?cid={save_cid}"}

    cookies = parse_cookie_string(cookie_str)

    # 验证关键Cookie字段
    required_keys = {"UID", "CID", "SEID"}
    missing = required_keys - set(cookies.keys())
    if missing:
        print(f"[警告] Cookie中缺少字段: {missing}，尝试继续...")

    session = requests.Session()
    session.cookies.update(cookies)

    results = {"success": [], "failed": [], "save_dir": f"https://115.com/?cid={save_cid}&offset=0&tab=&mode=wangpan"}

    # 获取签名参数
    try:
        sign, uid, ts = get_sign_and_uid(session)
        if verbose:
            print(f"[✓] 登录验证成功 (uid={uid[:6]}...)")
    except Exception as e:
        print(f"[✗] Cookie验证失败: {e}")
        for url in urls:
            results["failed"].append({"url": url, "reason": f"Cookie失效: {e}"})
        return results

    # 分批提交（每批最多15个）
    batch_size = 15
    for i in range(0, len(urls), batch_size):
        batch = urls[i:i + batch_size]

        try:
            if len(batch) == 1:
                resp_data = add_single_task(session, batch[0], save_cid, sign, uid, ts)
            else:
                resp_data = add_multiple_tasks(session, batch, save_cid, sign, uid, ts)

            if verbose:
                print(f"[API响应] {json.dumps(resp_data, ensure_ascii=False, indent=2)}")

            state = resp_data.get("state", False)
            if state:
                # 成功
                for url in batch:
                    results["success"].append({"url": url})
                    if verbose:
                        short = url[:60] + "..." if len(url) > 60 else url
                        print(f"[✓] 已提交: {short}")
            else:
                # API返回失败
                error_msg = resp_data.get("error_msg") or resp_data.get("error") or "未知原因"
                for url in batch:
                    results["failed"].append({"url": url, "reason": error_msg})
                    if verbose:
                        print(f"[✗] 提交失败: {error_msg}")

        except requests.RequestException as e:
            for url in batch:
                results["failed"].append({"url": url, "reason": f"网络错误: {e}"})
            if verbose:
                print(f"[✗] 网络请求失败: {e}")
        except Exception as e:
            for url in batch:
                results["failed"].append({"url": url, "reason": f"未知错误: {e}"})
            if verbose:
                print(f"[✗] 未知错误: {e}")

        # 批次间稍作等待，避免频率限制
        if i + batch_size < len(urls):
            time.sleep(1)

    return results


def check_task_list(cookie_str: str, page: int = 1) -> list[dict]:
    """查询当前离线任务列表（可选功能）"""
    cookies = parse_cookie_string(cookie_str)
    session = requests.Session()
    session.cookies.update(cookies)

    params = {"page": page}
    resp = session.get(API_TASK_LIST, params=params, headers=HEADERS, timeout=15)
    resp.raise_for_status()
    data = resp.json()

    if not data.get("state"):
        raise RuntimeError(f"获取任务列表失败: {data.get('error', '未知')}")

    tasks = data.get("tasks", [])
    return tasks


def main():
    parser = argparse.ArgumentParser(
        description="115网盘离线下载自动化工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 添加单个磁力链接
  python add_offline.py --cookie "UID=xxx;CID=xxx;SEID=xxx" \\
      --url "magnet:?xt=urn:btih:abc123..."

  # 从文件读取Cookie，添加多个链接
  python add_offline.py --cookie-file ~/.115_cookie \\
      --url "magnet:?xt=..." --url "ed2k://..."

  # 从文件批量读取链接（每行一个）
  python add_offline.py --cookie "..." --urls-file my_links.txt

  # 查看当前任务列表
  python add_offline.py --cookie "..." --list-tasks

  # 指定保存目录（默认已配置为用户指定目录）
  python add_offline.py --cookie "..." --url "magnet:..." --cid "591454992464977485"
        """
    )

    # Cookie来源（三选一）
    cookie_group = parser.add_mutually_exclusive_group()
    cookie_group.add_argument(
        "--cookie", "-c",
        type=str,
        help='115 Cookie字符串，格式: "UID=xxx; CID=xxx; SEID=xxx"'
    )
    cookie_group.add_argument(
        "--cookie-file",
        type=str,
        help="包含Cookie字符串的文件路径（文件内只需一行Cookie内容）"
    )

    # 资源链接
    parser.add_argument(
        "--url", "-u",
        action="append",
        dest="urls",
        metavar="URL",
        help="要离线下载的链接（可重复使用多次，最多15个）"
    )
    parser.add_argument(
        "--urls-file",
        type=str,
        help="包含多个链接的文件，每行一个链接"
    )

    # 目标目录
    parser.add_argument(
        "--cid",
        type=str,
        default=DEFAULT_SAVE_CID,
        help=f"115网盘目标目录ID（默认: {DEFAULT_SAVE_CID}）"
    )

    # 其他选项
    parser.add_argument(
        "--list-tasks",
        action="store_true",
        help="查询当前离线任务列表（不添加新任务）"
    )
    parser.add_argument(
        "--quiet", "-q",
        action="store_true",
        help="静默模式，只输出JSON结果"
    )
    parser.add_argument(
        "--output-json",
        type=str,
        help="将结果保存为JSON文件"
    )

    args = parser.parse_args()

    # ── 读取Cookie ──────────────────────────────────────────────
    cookie_str = None
    if args.cookie:
        cookie_str = args.cookie
    elif args.cookie_file:
        try:
            with open(args.cookie_file, "r", encoding="utf-8") as f:
                cookie_str = f.read().strip()
        except FileNotFoundError:
            print(f"[✗] Cookie文件不存在: {args.cookie_file}")
            sys.exit(1)
    else:
        # 尝试环境变量
        cookie_str = os.environ.get("P115_COOKIE")
        if not cookie_str:
            print("[✗] 未提供Cookie。请使用 --cookie、--cookie-file 或设置 P115_COOKIE 环境变量")
            sys.exit(1)

    # ── 查询任务列表模式 ─────────────────────────────────────────
    if args.list_tasks:
        try:
            tasks = check_task_list(cookie_str)
            if not tasks:
                print("当前没有离线任务")
            else:
                print(f"共 {len(tasks)} 个任务:")
                for t in tasks:
                    status_map = {0: "等待中", 1: "下载中", 2: "已完成", -1: "失败"}
                    status = status_map.get(t.get("status", 0), "未知")
                    name = t.get("name", "未知")
                    size = t.get("size", 0)
                    print(f"  [{status}] {name}  ({size // 1024 // 1024} MB)")
        except Exception as e:
            print(f"[✗] 获取任务列表失败: {e}")
            sys.exit(1)
        return

    # ── 收集链接 ─────────────────────────────────────────────────
    urls = list(args.urls or [])
    if args.urls_file:
        try:
            with open(args.urls_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#"):
                        urls.append(line)
        except FileNotFoundError:
            print(f"[✗] 链接文件不存在: {args.urls_file}")
            sys.exit(1)

    if not urls:
        print("[✗] 未提供任何链接。使用 --url 或 --urls-file 指定资源链接")
        sys.exit(1)

    if len(urls) > 15:
        print(f"[警告] 链接数量 {len(urls)} 超过15个，将分批提交")

    # ── 执行 ──────────────────────────────────────────────────────
    if not args.quiet:
        print(f"\n🚀 准备提交 {len(urls)} 个离线任务到115网盘...")
        print(f"📁 目标目录: https://115.com/?cid={args.cid}&offset=0&tab=&mode=wangpan\n")

    results = add_offline_tasks(
        cookie_str=cookie_str,
        urls=urls,
        save_cid=args.cid,
        verbose=not args.quiet,
    )

    # ── 输出结果 ─────────────────────────────────────────────────
    success_count = len(results["success"])
    failed_count  = len(results["failed"])

    if not args.quiet:
        print(f"\n{'='*50}")
        print(f"✅ 成功: {success_count} 个任务")
        print(f"❌ 失败: {failed_count} 个任务")
        print(f"📁 查看下载进度: {results['save_dir']}")
        print(f"{'='*50}")

        if results["failed"]:
            print("\n失败详情:")
            for item in results["failed"]:
                short = item['url'][:60] + "..." if len(item['url']) > 60 else item['url']
                print(f"  - {short}")
                print(f"    原因: {item['reason']}")

    # 保存JSON结果
    if args.output_json:
        with open(args.output_json, "w", encoding="utf-8") as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        if not args.quiet:
            print(f"\n结果已保存到: {args.output_json}")

    if args.quiet:
        print(json.dumps(results, ensure_ascii=False, indent=2))

    sys.exit(0 if failed_count == 0 else 1)


if __name__ == "__main__":
    main()
