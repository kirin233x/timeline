# 115网盘非官方 API 参考（离线下载相关）

> 本文档整理自社区逆向工程成果，适用于 Cookie 认证方式

## 基础信息

- **Base URL**: `https://115.com`
- **认证方式**: Cookie（UID + CID + SEID）
- **请求格式**: `application/x-www-form-urlencoded`
- **响应格式**: JSON

## 目标目录信息

- **目录CID**: `591454992464977485`
- **目录链接**: `https://115.com/?cid=591454992464977485&offset=0&tab=&mode=wangpan`

---

## API 1：获取离线空间信息（含Sign）

**每次提交任务前必须先调用此接口获取 `sign`、`uid`、`time`**

```
GET https://115.com/?ct=offline&ac=space
```

**响应示例：**
```json
{
  "state": 1,
  "sign": "abcdef1234567890...",
  "uid": 123456789,
  "time": 1703001234,
  "quota": 107374182400,
  "size": 5368709120,
  "url": {...}
}
```

---

## API 2：添加单个离线任务

```
POST https://115.com/web/lixian/?ct=lixian&ac=add_task_url
Content-Type: application/x-www-form-urlencoded
```

**请求参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `url` | string | ✅ | 磁力链接/直链/ed2k |
| `wp_path_id` | string | ✅ | 目标目录CID |
| `uid` | string | ✅ | 从 space 接口获取 |
| `sign` | string | ✅ | 从 space 接口获取 |
| `time` | string | ✅ | 从 space 接口获取（时间戳）|

**成功响应：**
```json
{
  "state": 1,
  "msg": "ok"
}
```

**失败响应：**
```json
{
  "state": 0,
  "error_msg": "该资源被举报，无法添加",
  "errno": 10008
}
```

---

## API 3：批量添加离线任务（最多15个）

```
POST https://115.com/web/lixian/?ct=lixian&ac=add_task_urls
Content-Type: application/x-www-form-urlencoded
```

**请求参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `url[0]` | string | ✅ | 第1个链接 |
| `url[1]` | string | | 第2个链接（以此类推）|
| `wp_path_id` | string | ✅ | 目标目录CID |
| `uid` | string | ✅ | 同上 |
| `sign` | string | ✅ | 同上 |
| `time` | string | ✅ | 同上 |

---

## API 4：查询离线任务列表

```
GET https://115.com/web/lixian/?ct=lixian&ac=task_lists
```

**Query参数：**

| 参数 | 说明 | 默认 |
|------|------|------|
| `page` | 页码，从1开始 | 1 |

**响应示例：**
```json
{
  "state": 1,
  "count": 5,
  "tasks": [
    {
      "name": "资源名称",
      "size": 1073741824,
      "status": 2,
      "percent": 100,
      "add_time": 1703001234,
      "last_update": 1703001300,
      "file_id": "xxx"
    }
  ]
}
```

**任务状态码：**
| 值 | 含义 |
|----|------|
| 0 | 等待中 |
| 1 | 下载中 |
| 2 | 已完成 |
| -1 | 失败/被屏蔽 |

---

## 常见错误码

| errno | 说明 | 处理方式 |
|-------|------|----------|
| 10008 | 资源被举报/屏蔽 | 换其他资源 |
| 10009 | 磁力链接无效 | 检查链接格式 |
| 911 | 风控触发 | 等待或更换Cookie |
| 403 | Cookie失效 | 重新获取Cookie |

---

## 支持的链接格式

- **磁力链接**: `magnet:?xt=urn:btih:...`
- **ed2k链接**: `ed2k://|file|...|size|hash|/`
- **HTTP/HTTPS直链**: `https://example.com/file.zip`
- **种子直链**: 指向 `.torrent` 文件的 HTTP 链接

---

## Python 调用示例

```python
import requests
import time

COOKIE = "UID=xxx; CID=xxx; SEID=xxx"
TARGET_CID = "591454992464977485"

session = requests.Session()
# 解析并设置Cookie
for kv in COOKIE.split(";"):
    k, v = kv.strip().split("=", 1)
    session.cookies.set(k.strip(), v.strip())

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Referer": "https://115.com/",
}

# Step 1: 获取sign
resp = session.get("https://115.com/?ct=offline&ac=space", headers=headers)
data = resp.json()
sign = data["sign"]
uid  = str(data["uid"])
ts   = str(data["time"])

# Step 2: 添加任务
form = {
    "url": "magnet:?xt=urn:btih:你的磁力链接",
    "wp_path_id": TARGET_CID,
    "uid": uid,
    "sign": sign,
    "time": ts,
}
resp = session.post(
    "https://115.com/web/lixian/?ct=lixian&ac=add_task_url",
    data=form,
    headers=headers
)
print(resp.json())
```
