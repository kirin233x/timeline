# 115网盘 Cookie 获取与配置指南

## Cookie的作用

115网盘官方API需要企业资质，个人用户使用 Cookie 模拟浏览器请求来完成认证。
Cookie 中最重要的三个字段是：

| 字段 | 说明 |
|------|------|
| `UID` | 用户ID |
| `CID` | 客户端ID（注意：这是Cookie字段，不是目录CID） |
| `SEID` | Session ID，最关键的认证令牌 |

## 如何获取Cookie

### 方法一：浏览器抓包（推荐，稳定）

1. 打开 [115.com](https://115.com) 并登录
2. 按 `F12` 打开开发者工具，切换到 **Network（网络）** 标签
3. 刷新页面
4. 在请求列表中点击任意一个 `115.com` 域名的请求
5. 在右侧 **Headers（请求头）** 中找到 `Cookie:` 字段
6. 复制整行 Cookie 值

**Cookie示例格式：**
```
UID=123456789; CID=abcdef1234567890abcdef; SEID=abcdef1234567890; 115_lang=zh; ...
```

### 方法二：移动端抓包（更长效，推荐）

网页版Cookie有效期约7天，移动端Cookie更持久。

**iOS（使用Stream）：**
1. App Store 安装 Stream
2. 开启HTTPS抓包，安装证书
3. 打开115 App，随便点开一个文件/视频
4. 回到Stream，在抓包记录中找 `115.com` 请求
5. 复制 Cookie 字段

**Android：**
可使用 HttpCanary 或 Packet Capture 类似操作。

## 配置Cookie的三种方式

### 方式1：命令行参数（临时使用）
```bash
python add_offline.py \
  --cookie "UID=xxx; CID=xxx; SEID=xxx" \
  --url "magnet:?xt=..."
```

### 方式2：Cookie文件（推荐，长期使用）
```bash
# 创建Cookie文件（只需一行）
echo 'UID=xxx; CID=xxx; SEID=xxx; 115_lang=zh' > ~/.115_cookie
chmod 600 ~/.115_cookie  # 保护隐私

# 使用Cookie文件
python add_offline.py \
  --cookie-file ~/.115_cookie \
  --url "magnet:?xt=..."
```

### 方式3：环境变量
```bash
# 在 ~/.bashrc 或 ~/.zshrc 中添加
export P115_COOKIE="UID=xxx; CID=xxx; SEID=xxx"

# 之后直接运行（无需指定Cookie）
python add_offline.py --url "magnet:?xt=..."
```

## OpenClaw 中的配置方式

在 OpenClaw 的 Skill 配置中，建议将Cookie存储为**环境变量**：

1. 在 OpenClaw 配置文件中添加：
```json
{
  "env": {
    "P115_COOKIE": "你的Cookie字符串"
  }
}
```

2. 或者在 SKILL.md 执行脚本时，通过 `--cookie` 参数传入。

## Cookie失效处理

Cookie 会在以下情况失效：
- 网页端重新登录（会使网页端Cookie失效）
- 超过有效期（网页端约7天）
- 被115检测到异常行为

**失效症状：** 脚本返回 `"获取sign失败（可能Cookie已失效）"` 错误

**解决方法：** 重新抓取Cookie，按上述步骤重新获取。

## 安全提示

- Cookie相当于账号密码，请妥善保管
- 不要把Cookie提交到Git仓库
- 建议使用 `chmod 600 ~/.115_cookie` 限制文件权限
