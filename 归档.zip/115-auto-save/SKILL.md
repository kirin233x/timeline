---
name: 115-auto-save
description: 自动搜索资源并推送到115网盘离线下载。当用户说"帮我找XXX存到115"、"搜索XXX离线下载"、"把XXX推送到115"、"找磁力链接存115"时触发。Skill会自动：1) 联网搜索资源的磁力链接或直链，2) 调用115网盘离线下载API将资源添加到指定目录，3) 返回任务状态。即使用户只说"帮我找一下XXX"但上下文中有115相关配置，也应优先使用此Skill。
---

# 115网盘自动资源搜索 & 离线下载 Skill

## 概述

本 Skill 实现全自动的资源搜索 → 115网盘离线存储流程：
1. 使用 web_search 搜索目标资源的磁力链接 / 直链 / ed2k 链接
2. 通过115网盘非官方 Cookie API 提交离线下载任务
3. 将任务存入用户指定目录（CID: `591454992464977485`）

## 配置要求

运行前需要在环境中配置115 Cookie，见 `references/cookie-setup.md`。

## 执行流程

### Step 1：理解用户需求

从用户消息中提取：
- **资源名称**：影视名称、软件名、文档名等
- **资源类型**：电影/剧集/软件/音乐/其他
- **附加筛选**：分辨率、语言、年份、季/集数等

### Step 2：搜索资源链接

使用 web_search 进行多轮搜索，策略如下：

```
首选搜索词（按优先级）：
1. "{资源名} 磁力链接 magnet"
2. "{资源名} 迅雷链接 thunder"  
3. "{资源名} ed2k"
4. "{资源名} torrent 下载"
5. "{资源名} 直链下载"
```

**链接提取规则：**
- 磁力链接格式：`magnet:?xt=urn:btih:...`
- ed2k格式：`ed2k://|file|...|/`
- 种子直链：`.torrent` 结尾的 URL
- HTTP直链：视频/文件直链

**质量评估（优先选择）：**
- 来源可信（知名BT站、字幕组发布页）
- 有种子评论/做种数据
- 文件大小合理
- 名称与目标资源匹配

### Step 3：调用115离线下载API

读取 `scripts/add_offline.py` 并执行，或直接按以下逻辑调用：

**核心API端点：**
```
单个任务：POST https://115.com/web/lixian/?ct=lixian&ac=add_task_url
多个任务：POST https://115.com/web/lixian/?ct=lixian&ac=add_task_urls
```

**请求参数：**
```python
# 单个链接
form_data = {
    "url": "<磁力链接或直链>",
    "wp_path_id": "591454992464977485",  # 目标目录CID
    "uid": "<从Cookie中提取>",
    "sign": "<需要从API获取>",
    "time": "<当前时间戳>"
}

# 多个链接（最多15个）
form_data = {
    "url[0]": "<链接1>",
    "url[1]": "<链接2>",
    ...
    "wp_path_id": "591454992464977485",
    "uid": "<从Cookie中提取>",
    "sign": "<需要从API获取>",
    "time": "<当前时间戳>"
}
```

**获取sign和uid的前置请求：**
```
GET https://115.com/?ct=offline&ac=space
```
响应中包含 `sign`、`uid`、`time` 字段。

### Step 4：执行脚本

使用 `bash_tool` 执行 `scripts/add_offline.py`，传入：
- `--cookie`：用户的115 Cookie字符串
- `--url`：找到的资源链接（支持多个）
- `--cid`：目标目录ID（默认已配置为 `591454992464977485`）

### Step 5：反馈结果

向用户报告：
- ✅ 成功添加的任务名称和数量
- ❌ 失败的链接和原因（如资源被屏蔽）
- 📁 下载目标目录链接：`https://115.com/?cid=591454992464977485&offset=0&tab=&mode=wangpan`
- ⏱ 预计可在115网盘查看任务进度

## 注意事项

- Cookie 中最重要的字段是 `UID`、`CID`、`SEID`（注意：这里的CID是Cookie字段名，不是目录ID）
- 每次请求前需要重新获取 `sign` 和 `time`，不可复用
- 115对部分资源有审查，提交成功不代表一定会下载完成
- 单次最多提交15个磁力链接
- 如搜索结果质量不佳，应多尝试几种搜索词再告知用户

## 调用脚本

详细的 Python 执行脚本见 `scripts/add_offline.py`
Cookie 配置说明见 `references/cookie-setup.md`
API 接口详情见 `references/api-reference.md`
