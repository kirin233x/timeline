---
name: android-remote-control
description: 远程控制 Android 设备，支持截图、UI 分析、点击、滑动、文字输入及 App 管理。使用 uiautomator2 + ADB 连接设备。当用户需要：(1) 查看手机屏幕或界面元素，(2) 自动化操作手机 App（点击按钮、输入文字、滑动页面），(3) 远程安装/卸载/启动软件，(4) 跨设备协作或手机自动化流程时，使用此技能。即使用户只说"帮我操作手机"、"看一下手机屏幕"、"打开某个App"也应触发。
---

# Android Remote Control (安卓远程分身)

通过 `uiautomator2` 实现对 Android 设备的高效远程操控。

## 核心脚本

`{baseDir}/scripts/remote_control.py` — 单一入口，所有操作通过子命令调用。

## 操作指南

### 1. 环境准备

首次使用前安装依赖：
```bash
pip install uiautomator2
```

确保手机已开启 USB 调试，且 ADB 已连接（USB 或 WiFi 均可）。
脚本会自动检测系统 ADB，也可通过环境变量 `ADB_PATH` 指定路径。

### 2. 命令速查

#### 截图 + UI 分析（推荐首选，一次获取全部信息）
```bash
python {baseDir}/scripts/remote_control.py snap_ui workspace/screen.jpg workspace/ui.xml
```
同时保存截图和 UI 层级文件。UI 层级包含所有可见元素的文本、坐标、类型，可直接用于定位点击目标，**无需视觉模型**。

#### 仅截图
```bash
python {baseDir}/scripts/remote_control.py snap workspace/screen.jpg
```

#### 仅获取 UI 层级
```bash
python {baseDir}/scripts/remote_control.py dump_ui workspace/ui.xml
```

#### 点击操作（三种方式，按优先级选择）
```bash
# 方式1（推荐）：按文本点击，最稳定
python {baseDir}/scripts/remote_control.py click_text "登录"

# 方式2：按 resource-id 点击
python {baseDir}/scripts/remote_control.py click_id "com.example:id/btn_login"

# 方式3：按坐标点击（归一化坐标 0.0-1.0）
python {baseDir}/scripts/remote_control.py click 0.5 0.8
```

#### 滑动
```bash
# 上滑（翻页）
python {baseDir}/scripts/remote_control.py swipe up

# 自定义滑动：从 (x1,y1) 到 (x2,y2)，归一化坐标
python {baseDir}/scripts/remote_control.py swipe 0.5 0.8 0.5 0.2
```

#### 文字输入
```bash
python {baseDir}/scripts/remote_control.py input "Hello World"
```

#### 按键
```bash
python {baseDir}/scripts/remote_control.py key back
python {baseDir}/scripts/remote_control.py key home
python {baseDir}/scripts/remote_control.py key enter
```

#### App 管理
```bash
# 启动 App
python {baseDir}/scripts/remote_control.py start com.tencent.mm

# 停止 App
python {baseDir}/scripts/remote_control.py stop com.tencent.mm

# 列出运行中的 App
python {baseDir}/scripts/remote_control.py list_apps

# 获取当前前台 App
python {baseDir}/scripts/remote_control.py current_app
```

#### 设备信息
```bash
python {baseDir}/scripts/remote_control.py info
```

### 3. 典型工作流

**高效操作循环（推荐）：**
1. 执行 `snap_ui` 同时获取截图和 UI 层级
2. 阅读 UI 层级 XML，找到目标元素的文本或 resource-id
3. 用 `click_text` 或 `click_id` 精确点击 — 不需要坐标，不需要视觉模型
4. 重复以上步骤

**仅在以下情况使用坐标点击：**
- UI 层级中找不到目标元素（如 WebView、Canvas 内容）
- 需要点击没有文本标识的图形元素

### 4. 注意事项

- 首次连接需在手机端确认"允许 USB 调试"
- WiFi 连接：先 `adb tcpip 5555`，再 `adb connect <手机IP>:5555`
- 如遇权限问题，检查 uiautomator2 的 ATX agent 是否已安装（首次会自动安装）
