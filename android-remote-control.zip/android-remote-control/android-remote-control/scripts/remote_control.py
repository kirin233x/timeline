"""
Android Remote Control — optimized for speed.
Key optimizations:
  1. Single u2.connect() cached for the process lifetime
  2. snap_ui: screenshot + UI hierarchy in one call (no VLM needed)
  3. click_text / click_id: element-based clicking (no coordinate guessing)
  4. Auto-detect ADB path across platforms
"""

import uiautomator2 as u2
import os
import sys
import json
import shutil

# ── Persistent connection (the #1 speed fix) ────────────────────────
_device = None

def get_device():
    """Connect once, reuse forever."""
    global _device
    if _device is not None:
        return _device

    # Auto-detect ADB: env var → PATH → common locations
    adb_extra = os.environ.get("ADB_PATH", "")
    if adb_extra and adb_extra not in os.environ.get("PATH", ""):
        os.environ["PATH"] += os.pathsep + adb_extra

    if not shutil.which("adb"):
        # Try common install locations
        common_paths = [
            r"C:\Program Files (x86)\Camo Studio\Adb",
            os.path.expanduser("~/Android/Sdk/platform-tools"),
            os.path.expanduser("~/Library/Android/sdk/platform-tools"),
            "/usr/local/bin",
        ]
        for p in common_paths:
            if os.path.isdir(p) and os.path.exists(os.path.join(p, "adb")) or \
               os.path.exists(os.path.join(p, "adb.exe")):
                os.environ["PATH"] += os.pathsep + p
                break

    try:
        _device = u2.connect()
        return _device
    except Exception as e:
        print(f"ERROR: Cannot connect to device. Ensure USB debugging is on and ADB sees the device.\n{e}")
        sys.exit(1)


def _get_screen_size():
    d = get_device()
    info = d.info
    return info["displayWidth"], info["displayHeight"]


# ── Commands ─────────────────────────────────────────────────────────

def cmd_snap(output_path="screenshot.jpg"):
    """Take a screenshot."""
    d = get_device()
    d.screenshot(output_path)
    print(f"OK screenshot → {output_path}")


def cmd_dump_ui(output_path="ui.xml"):
    """Dump the UI hierarchy to XML. Contains text, resource-id, bounds for every element."""
    d = get_device()
    xml = d.dump_hierarchy()
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(xml)
    print(f"OK ui_hierarchy → {output_path}")


def cmd_snap_ui(img_path="screenshot.jpg", xml_path="ui.xml"):
    """Screenshot + UI hierarchy in one call — the recommended first step."""
    d = get_device()
    d.screenshot(img_path)
    xml = d.dump_hierarchy()
    with open(xml_path, "w", encoding="utf-8") as f:
        f.write(xml)
    print(f"OK screenshot → {img_path}")
    print(f"OK ui_hierarchy → {xml_path}")


def cmd_click(x, y):
    """Click at normalized coordinates (0.0-1.0)."""
    d = get_device()
    w, h = _get_screen_size()
    abs_x, abs_y = int(float(x) * w), int(float(y) * h)
    d.click(abs_x, abs_y)
    print(f"OK clicked ({abs_x}, {abs_y})")


def cmd_click_text(text):
    """Click the first element matching this text. Fast and reliable."""
    d = get_device()
    el = d(text=text)
    if not el.exists:
        # Fallback: try textContains
        el = d(textContains=text)
    if el.exists:
        el.click()
        print(f"OK clicked element with text '{text}'")
    else:
        print(f"ERROR: No element found with text '{text}'")
        sys.exit(1)


def cmd_click_id(resource_id):
    """Click element by resource-id."""
    d = get_device()
    el = d(resourceId=resource_id)
    if el.exists:
        el.click()
        print(f"OK clicked element with id '{resource_id}'")
    else:
        print(f"ERROR: No element found with id '{resource_id}'")
        sys.exit(1)


def cmd_swipe(*args):
    """
    Swipe gesture.
    Usage:
      swipe up|down|left|right          — preset swipe
      swipe <x1> <y1> <x2> <y2>        — custom (normalized 0.0-1.0)
    """
    d = get_device()
    presets = {
        "up":    (0.5, 0.75, 0.5, 0.25),
        "down":  (0.5, 0.25, 0.5, 0.75),
        "left":  (0.75, 0.5, 0.25, 0.5),
        "right": (0.25, 0.5, 0.75, 0.5),
    }
    if len(args) == 1 and args[0] in presets:
        x1, y1, x2, y2 = presets[args[0]]
    elif len(args) == 4:
        x1, y1, x2, y2 = (float(a) for a in args)
    else:
        print("Usage: swipe up|down|left|right  OR  swipe <x1> <y1> <x2> <y2>")
        sys.exit(1)

    w, h = _get_screen_size()
    d.swipe(int(x1*w), int(y1*h), int(x2*w), int(y2*h), duration=0.3)
    print(f"OK swiped ({x1},{y1}) → ({x2},{y2})")


def cmd_input(text):
    """Type text into the currently focused input field."""
    d = get_device()
    d.send_keys(text)
    print(f"OK input '{text}'")


def cmd_key(key_name):
    """Press a key: back, home, enter, recent, volume_up, volume_down, power."""
    d = get_device()
    key_map = {
        "back": "back", "home": "home", "enter": "enter",
        "recent": "recent", "volume_up": "volume_up",
        "volume_down": "volume_down", "power": "power",
        "menu": "menu", "delete": "delete",
    }
    k = key_map.get(key_name.lower())
    if k:
        d.press(k)
        print(f"OK pressed '{k}'")
    else:
        print(f"ERROR: Unknown key '{key_name}'. Available: {', '.join(key_map.keys())}")
        sys.exit(1)


def cmd_start(package):
    """Launch an app by package name."""
    d = get_device()
    d.app_start(package)
    print(f"OK started {package}")


def cmd_stop(package):
    """Force-stop an app."""
    d = get_device()
    d.app_stop(package)
    print(f"OK stopped {package}")


def cmd_list_apps():
    """List running apps."""
    d = get_device()
    apps = d.app_list_running()
    for a in apps:
        print(a)
    print(f"OK {len(apps)} running apps")


def cmd_current_app():
    """Show current foreground app."""
    d = get_device()
    info = d.app_current()
    print(json.dumps({"package": info.get("package", ""), "activity": info.get("activity", "")}, ensure_ascii=False))


def cmd_info():
    """Device info summary."""
    d = get_device()
    info = d.info
    print(json.dumps({
        "brand": info.get("productName", ""),
        "model": d.device_info.get("model", ""),
        "sdk": info.get("sdkInt", ""),
        "screen": f"{info['displayWidth']}x{info['displayHeight']}",
        "battery": d.device_info.get("battery", {}).get("level", "?"),
    }, ensure_ascii=False, indent=2))


# ── CLI router ───────────────────────────────────────────────────────

COMMANDS = {
    "snap":        (cmd_snap,        "[output_path]"),
    "dump_ui":     (cmd_dump_ui,     "[output_path]"),
    "snap_ui":     (cmd_snap_ui,     "[img_path] [xml_path]"),
    "click":       (cmd_click,       "<x> <y>"),
    "click_text":  (cmd_click_text,  "<text>"),
    "click_id":    (cmd_click_id,    "<resource_id>"),
    "swipe":       (cmd_swipe,       "up|down|left|right | <x1> <y1> <x2> <y2>"),
    "input":       (cmd_input,       "<text>"),
    "key":         (cmd_key,         "back|home|enter|recent|..."),
    "start":       (cmd_start,       "<package>"),
    "stop":        (cmd_stop,        "<package>"),
    "list_apps":   (cmd_list_apps,   ""),
    "current_app": (cmd_current_app, ""),
    "info":        (cmd_info,        ""),
}

def main():
    if len(sys.argv) < 2 or sys.argv[1] not in COMMANDS:
        print("Android Remote Control\n")
        print("Usage: python remote_control.py <command> [args]\n")
        print("Commands:")
        for name, (_, usage) in COMMANDS.items():
            print(f"  {name:14s} {usage}")
        sys.exit(0 if len(sys.argv) < 2 else 1)

    cmd_name = sys.argv[1]
    func, _ = COMMANDS[cmd_name]
    args = sys.argv[2:]

    try:
        func(*args)
    except TypeError as e:
        _, usage = COMMANDS[cmd_name]
        print(f"ERROR: Wrong arguments for '{cmd_name}'. Usage: {cmd_name} {usage}")
        sys.exit(1)

if __name__ == "__main__":
    main()
